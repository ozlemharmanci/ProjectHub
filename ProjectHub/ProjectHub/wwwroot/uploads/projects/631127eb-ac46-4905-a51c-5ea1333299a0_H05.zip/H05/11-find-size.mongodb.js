use("ShellDbOrnek");
db.ogrenciler.find(
    {
        hobiler:{$size:3}
    }
);