
use("ShellDbOrnek");

db.ogrenciler.aggregate([
    {$project: {
      isim:1,
      yas:1,
      dogumTarihi:1,
      _id:0,
      dogumYili: {$year:"$dogumTarihi"}
      
    }}
]);



// $year: Tarihin yılını alır.

// $month: Tarihin ayını alır.

// $dayOfMonth: Tarihin ayın kaçıncı günü olduğunu alır.

// $hour: Tarihin saatini alır.

// $minute: Tarihin dakikasını alır.

// $second: Tarihin saniyesini alır.

// $millisecond: Tarihin milisaniyesini alır.

// $dateToString: Tarihi stringe çevirir.