use("ShellDbOrnek");

db.ogrenciler.aggregate([
    {project:{isim: 1, yas: 1}}
]);