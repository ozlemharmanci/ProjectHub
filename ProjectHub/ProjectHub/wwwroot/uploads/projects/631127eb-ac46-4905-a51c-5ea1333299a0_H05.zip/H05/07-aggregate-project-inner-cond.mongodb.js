use("ShellDbOrnek");

db.ogrenciler.aggregate([
    {$project: {
        isim:1,
        yas:1,
        _id:0,
        yasGrubu: {$cond:{
            if:{$gt: ["$yas", 30]},
            then:"30+",
            else:{
                $cond:{
                    if:{$gte: ["$yas", 25]},
                    then:"25-30",
                    else:"25-"
                }
            }

        }}
    }}
]);