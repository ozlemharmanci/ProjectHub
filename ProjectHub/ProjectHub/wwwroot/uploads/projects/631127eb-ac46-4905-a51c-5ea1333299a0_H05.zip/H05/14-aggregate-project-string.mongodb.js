use("ShellDbOrnek");

db.ogrenciler.aggregate([
    {$project: {
      isim:1,
      _id:0,
      buyukHarf:{ $concat: ["$isim", "15"]}
    }}
]);


// $concat: Stringleri birleştirir.

// $substr: Stringin bir bölümünü alır.

// $toLower: Stringi küçük harfe çevirir.

// $toUpper: Stringi büyük harfe çevirir.

// $trim: Stringin başındaki ve sonundaki boşlukları kaldırır.

// $ltrim: Stringin başındaki boşlukları kaldırır.

// $rtrim: Stringin sonundaki boşlukları kaldırır.

// $strLenBytes: Stringin byte uzunluğunu döner.

// $strLenCP: Stringin karakter uzunluğunu döner.