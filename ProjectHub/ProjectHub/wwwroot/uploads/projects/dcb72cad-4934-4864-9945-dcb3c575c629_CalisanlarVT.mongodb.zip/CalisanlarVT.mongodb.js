use ("calisanlar");

db.createCollection("calisanlar")
db.calisanlar.insertMany([
    {   ad: "Ayşe",
        soyad:"Mutlu",
	 	maas:60000,
	 	departman: "Bilişim Teknolojileri",
        gorev: "Yazılım Geliştirici",
        dogumTarihi: new Date("1990-05-15"),
        cinsiyet: "Kadın",
        telefon: "555-123-4567",
        adres: {
            sokak: "İst Sokak",
            sehir: "İstanbul",
            postaKodu: "34000"
        },
        yetenekler: ["Java", "Python", "JavaScript"],
	},
    {
        ad: "Ahmet",
        soyad:"Yılmaz",
        maas:70000,
        departman: "Pazarlama",
        gorev: "Pazarlama Uzmanı",
        dogumTarihi: new Date("1985-03-22"),
        cinsiyet: "Erkek",
        telefon: "555-987-6543",
        adres: {
            sokak: "Anka Caddesi",
            sehir: "Ankara",
            postaKodu: "06000"
        },
        yetenekler: ["Pazarlama", "Satış", "İletişim"],
    },
    {
        ad: "Mehmet",
        soyad:"Kaya",
        maas:80000,
        departman: "Finans",
        gorev: "Finans Müdürü",
        dogumTarihi: new Date("1980-11-10"),
        cinsiyet: "Erkek",
        telefon: "555-456-7890",
        adres: {
            sokak: "İzmir Bulvarı",
            sehir: "İzmir",
            postaKodu: "35000"
        },
        yetenekler: ["Finans", "Analiz", "Raporlama"],
    },
    {
        ad: "Fatma",
        soyad:"Demir",
        maas:75000,
        departman: "İnsan Kaynakları",
        gorev: "İK Uzmanı",
        dogumTarihi: new Date("1992-07-30"),
        cinsiyet: "Kadın",
        telefon: "555-321-6543",
        adres: {
            sokak: "Çiçek Sokak",
            sehir: "Bursa",
            postaKodu: "16000"
        },
        yetenekler: ["İK Yönetimi", "Eğitim", "İletişim"],
    },
    {
        ad: "Ali",
        soyad:"Çelik",
        maas:90000,
        departman: "Proje Yönetimi",
        gorev: "Proje Yöneticisi",
        dogumTarihi: new Date("1988-09-05"),
        cinsiyet: "Erkek",
        telefon: "555-654-3210",
        adres: {
            sokak: "Deniz Caddesi",
            sehir: "Antalya",
            postaKodu: "07000"
        },
        yetenekler: ["Proje Yönetimi", "Liderlik", "İletişim"],
    },
    {
        ad: "Zeynep",
        soyad:"Arslan",
        maas:65000,
        departman: "İnsan Kaynakları",
        gorev: "Müşteri Temsilcisi",
        dogumTarihi: new Date("1995-12-20"),
        cinsiyet: "Kadın",
        telefon: "555-789-0123",
        adres: {
            sokak: "Gül Sokak",
            sehir: "Konya",
            postaKodu: "42000"
        },
        yetenekler: ["Müşteri İlişkileri", "İletişim", "Problem Çözme"],
    },
    {
        ad: "Emre",
        soyad:"Koç",
        maas:85000,
        departman: "Bilişim Teknolojileri",
        gorev: "Sistem Yöneticisi",
        dogumTarihi: new Date("1987-04-18"),
        cinsiyet: "Erkek",
        telefon: "555-234-5678",
        adres: {
            sokak: "Kaya Caddesi",
            sehir: "Kayseri",
            postaKodu: "38000"
        },
        yetenekler: ["Sistem Yönetimi", "Ağ Güvenliği", "Veritabanı Yönetimi"],
    },
    {
        ad: "Elif",
        soyad:"Yurt",
        maas:72000,
        departman: "Pazarlama",
        gorev: "Pazarlama Müdürü",
        dogumTarihi: new Date("1986-08-25"),
        cinsiyet: "Kadın",
        telefon: "555-345-6789",
        adres: {
            sokak: "Köprü Sokak",
            sehir: "Sakarya",
            postaKodu: "54000"
        },
        yetenekler: ["Pazarlama", "Strateji", "İletişim"],
    },
    {
        ad: "Burak",
        soyad:"Aydın",
        maas:95000,
        departman: "Finans",
        gorev: "Finans Analisti",
        dogumTarihi: new Date("1983-10-12"),
        cinsiyet: "Erkek",
        telefon: "555-678-9012",
        adres: {
            sokak: "Yıldız Caddesi",
            sehir: "Trabzon",
            postaKodu: "61000"
        },
        yetenekler: ["Finans", "Analiz", "Raporlama"],
    },
    {
        ad: "Cem",
        soyad:"Öztürk",
        maas:78000,
        departman: "Proje Yönetimi",
        gorev: "Proje Asistanı",
        dogumTarihi: new Date("1991-06-15"),
        cinsiyet: "Erkek",
        telefon: "555-890-1234",
        adres: {
            sokak: "Orman Sokak",
            sehir: "Samsun",
            postaKodu: "55000"
        },
        yetenekler: ["Proje Yönetimi", "İletişim", "Organizasyon"],
    },
    {
        ad: "Seda",
        soyad:"Kara",
        maas:68000,
        departman: "İnsan Kaynakları",
        gorev: "İK Müdürü",
        dogumTarihi: new Date("1989-02-28"),
        cinsiyet: "Kadın",
        telefon: "555-456-1234",
        adres: {
            sokak: "Deniz Sokak",
            sehir: "Gaziantep",
            postaKodu: "27000"
        },
        yetenekler: ["İK Yönetimi", "Eğitim", "İletişim"],
    },
    {
        ad: "Oğuz",
        soyad:"Polat",
        maas:82000,
        departman: "Bilişim Teknolojileri",
        gorev: "Veritabanı Yöneticisi",
        dogumTarihi: new Date("1984-01-10"),
        cinsiyet: "Erkek",
        telefon: "555-234-8901",
        adres: {
            sokak: "Göl Caddesi",
            sehir: "Mersin",
            postaKodu: "33000"
        },
        yetenekler: ["Veritabanı Yönetimi", "SQL", "Ağ Güvenliği"],
    },
    {
        ad: "Derya",
        soyad:"Yılmaz",
        maas:72000,
        departman: "Pazarlama",
        gorev: "Pazarlama Asistanı",
        dogumTarihi: new Date("1993-11-05"),
        cinsiyet: "Kadın",
        telefon: "555-678-2345",
        adres: {
            sokak: "Kumsal Sokak",
            sehir: "Antalya",
            postaKodu: "07000"
        },
        yetenekler: ["Pazarlama", "İletişim", "Sosyal Medya"],
    },
    {
        ad: "Serkan",
        soyad:"Kurt",
        maas:90000,
        departman: "Finans",
        gorev: "Finans Analisti",
        dogumTarihi: new Date("1982-03-15"),
        cinsiyet: "Erkek",
        telefon: "555-789-3456",
        adres: {
            sokak: "Çam Sokak",
            sehir: "Bursa",
            postaKodu: "16000"
        },
        yetenekler: ["Finans", "Analiz", "Raporlama"],
    },
    {
        ad: "Aylin",
        soyad:"Akman",
        maas:70000,
        departman: "Proje Yönetimi",
        gorev: "Proje Yöneticisi",
        dogumTarihi: new Date("1987-05-20"),
        cinsiyet: "Kadın",
        telefon: "555-890-4567",
        adres: {
            sokak: "Kaya Caddesi",
            sehir: "İstanbul",
            postaKodu: "34000"
        },
        yetenekler: ["Proje Yönetimi", "Liderlik", "İletişim"],
    }
]);

//1)
use("calisanlar");
db.calisanlar.find({departman:"Bilişim Teknolojileri"});


//2)
use("calisanlar");
db.calisanlar.find({departman:"İnsan Kaynakları"}).count();


//3)
use("calisanlar");
db.calisanlar.distinct("departman");

//4)
use("calisanlar");
db.calisanlar.find({"adres.sehir":{$in:["Bursa","İstanbul"]}});

//5)
use("calisanlar");
db.calisanlar.updateMany({},{$inc:{maas:1000}});

//6)
use("calisanlar");
db.calisanlar.find({maas:{$gte:80000}}).count();


//7)
use("calisanlar");
db.calisanlar.find({$and:[{maas:{$gt:40000}}, {"adres.sehir": "Bursa"}]});

//8)
use("calisanlar");
db.calisanlar.aggregate([
    { $group:{
      _id: "$departman",
      ortalamaMaas: {
        $avg:"$maas"
      }
    }}
])


//9)
use("calisanlar");
db.calisanlar.aggregate([
    {
        $match:{
            departman: "Proje Yönetimi"
        }
    },
    { $group: {
      _id:null,
      toplamMaas: {
        $sum:"$maas"
      }
    }}
])

//10)
use("calisanlar");
db.calisanlar.createIndex({yetenekler:"text"});
db.calisanlar.find({$text: {$search:"İletişim"}});