
use ('kutuphane')

db.createCollection("kitaplar")
db.kitaplar.insertMany([
    { "kitap_adi": "Sefiller", 
        "yazar": "Victor Hugo", 
        "yayinevi": "İş Bankası Yayınları", 
        "yil": 1862, 
        "sayfa_sayisi": 1234 
    },
    { "kitap_adi": "Suç ve Ceza", 
        "yazar": "Fyodor Dostoyevski", 
        "yayinevi": "İş Bankası Yayınları", 
        "yil": 1866, 
        "sayfa_sayisi": 672 
    },
    { "kitap_adi": "Küçük Prens", 
        "yazar": "Antoine de Saint-Exupéry", 
        "yayinevi": "İş Bankası Yayınları", 
        "yil": 1943, 
        "sayfa_sayisi": 96 
    },
    { "kitap_adi": "Yüzüklerin Efendisi", 
        "yazar": "J.R.R. Tolkien", 
        "yayinevi": "İş Bankası Yayınları", 
        "yil": 1954, 
        "sayfa_sayisi": 1216 
    },
    { "kitap_adi": "Bülbülü Öldürmek", 
        "yazar": "Harper Lee", 
        "yayinevi": "Can Yayınları", 
        "yil": 1960, 
        "sayfa_sayisi": 281 
    },
    { "kitap_adi": "1984", 
        "yazar": "George Orwell", 
        "yayinevi": "Can Yayınları", 
        "yil": 1949, 
        "sayfa_sayisi": 328 
    },
    { "kitap_adi": "Hayvan Çiftliği", 
        "yazar": "George Orwell", 
        "yayinevi": "Can Yayınları", 
        "yil": 1945, 
        "sayfa_sayisi": 112 
    },
    { "kitap_adi": "Savaş ve Barış", 
        "yazar": "Lev Tolstoy", 
        "yayinevi": "Altın Yayınları", 
        "yil": 1869, 
        "sayfa_sayisi": 1225 
    },
    { "kitap_adi": "Karamazov Kardeşler", 
        "yazar": "Fyodor Dostoyevski", 
        "yayinevi": "Altın Yayınları", 
        "yil": 1860, 
        "sayfa_sayisi": 521 
    },
    { "kitap_adi": "Gece Uçuşu", 
        "yazar": "Antoine de Saint-Exupéry", 
        "yayinevi": "Kronik Yayınları", 
        "yil": 1937,
        "sayfa_sayisi": 203
    },
    { "kitap_adi": "Hobbit", 
        "yazar": "J.R.R. Tolkien", 
        "yayinevi": "Yapı Kredi Yayınları", 
        "yil": 1949, 
        "sayfa_sayisi": 1516 
    },
    { "kitap_adi": "Tespih Ağacının Gölgesinde", 
        "yazar": "Harper Lee", 
        "yayinevi": "Yapı Kredi Yayınları", 
        "yil": 1965, 
        "sayfa_sayisi": 181 
    },
    { "kitap_adi": "Notre Dame'ın Kamburu", 
        "yazar": "Victor Hugo", 
        "yayinevi": "Altın Yayınları", 
        "yil": 1875, 
        "sayfa_sayisi": 1025
    }
])


//1)
use("kutuphane");
db.kitaplar.aggregate([
  { $sort: { sayfa_sayisi: -1 } },
  {
    $group: {
      _id: "$yazar",
      en_yuksek_kitap: { $first: "$kitap_adi" },
      sayfa: { $first: "$sayfa_sayisi" }
    }
  }
])



//2)
use("kutuphane");
db.kitaplar.aggregate([
  { $group: { _id:"$yayinevi", kitap_sayisi:{$sum:1}}}
])


//3)
use("kutuphane");
db.kitaplar.aggregate([
  { $match: { yazar: {$in:["George Orwell", "Harper Lee"]}},
  {
    $group: {
      _id: null,
      ortalama_yil: { $avg: "$yil" }
    }
  }
])


//4) 
use("kutuphane");
db.kitaplar.find(
  { sayfa_sayisi: { $gt: 1000 } },
  { yazar: 1, kitap_adi: 1, sayfa_sayisi: 1, _id: 0 }
).sort({ sayfa_sayisi: -1 })


//5)
use("kutuphane");
db.kitaplar.updateOne(
  { kitap_adi: "1984" },
  { $set: { sayfa_sayisi: 340 } }
)



//6)
use("kutuphane");
db.kitaplar.aggregate([
  { $match: { yil: { $lt: 1950 } } },
  {
    $group: {
      _id: null,
      ortalama_sayfa: { $avg: "$sayfa_sayisi" }
    }
  }
])

//7)
use("kutuphane")
db.kitaplar.deleteMany({yazar: "Victor Hugo"});

//8)
use("kutuphane");
db.kitaplar.updateMany({}, [
  { $set: { basim_tarihi: { $dateFromParts: { year: "$yil", month: 1, day: 1 } } } }
])
db.kitaplar.createIndex(
  { basim_tarihi: 1 },
  { expireAfterSeconds: 60*60*24*365 }  
)



//9)
use("kutuphane");




//10)
use("kutuphane");
db.kitaplar.createIndex({ yayinevi: 1 })
db.kitaplar.find({ yayinevi: "İş Bankası Yayınları" })



